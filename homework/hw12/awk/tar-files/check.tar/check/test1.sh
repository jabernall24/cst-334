#!/bin/bash
# test 1
test $(./check <<< "0 ;") = yes
