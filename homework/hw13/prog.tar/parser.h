#ifndef PARSER_INC
#define PARSER_INC

// parser methods
PROG *parse();

#endif
